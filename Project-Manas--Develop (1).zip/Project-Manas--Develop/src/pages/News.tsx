import "../components/news/News.scss";
import { NewsPage } from "./NewsPage";
export default NewsPage;