import imgslide from "../../assets/3.jpg";

export const data = [
  {
    id: Date.now(),
    title: "Мугалимдер күнү менен!",
    pretitle: "lorem ipsum dolar",
    image: imgslide,
  },
  {
    id: Date.now(),
    title: "Мугалимдер күнү менен!",
    pretitle: "lorem ipsum dolar",
    image: imgslide,
  },
  {
    id: Date.now(),
    title: "Мугалимдер күнү менен!",
    pretitle: "lorem ipsum dolar",
    image: imgslide,
  },
  {
    id: Date.now(),
    title: "Мугалимдер күнү менен!",
    pretitle: "lorem ipsum dolar",
    image: imgslide,
  },
];
