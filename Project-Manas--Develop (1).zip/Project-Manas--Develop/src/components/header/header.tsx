import { Link } from "react-router-dom";
import headerimg from "../../assets/1.jpg";
import headerlogo from "../../assets/logo.png";
import "./header.scss";
function Header({ setInput }: any) {
  return (
    <>
      <header className="header">
        <div className="header__content">
          <div className="header__content__image__wrap">
            <img
              onClick={() => setInput(false)}
              className="header__content__image__wrap__image"
              src={headerimg}
              alt=""
            />
          </div>
          <div className="container">
            <div className="header__logo">
              <h1 className="header__logo__box">
                <div className="header__logo__box__wrap">
                  <img
                    style={{ width: "130px", height: "130px" }}
                    src={headerlogo}
                    alt=""
                  />
                </div>
                <div className="header__logo__info">
                  <Link to="/" className="header__logo__title">
                    «Манас» жатак-лицейи.
                  </Link>
                  <h3 className="header__logo__pretitle">Талас району</h3>
                </div>
              </h1>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
