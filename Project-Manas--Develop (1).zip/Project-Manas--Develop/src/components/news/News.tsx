import { useEffect, useState } from "react";
import "./News.scss";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../../.fireBase/FireBase";
import { Link, NavLink } from "react-router-dom";
import NewsChild from "./NewsChild";
import { NewsType } from "../../utils/interface";
function News() {
  const [data, setData] = useState<[]>([]);
  useEffect(() => {
    async function fetchData() {
      try {
        const ref = collection(db, "users");
        const snapShot: any = await getDocs(ref);
        setData(
          snapShot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }))
        );
      } catch (error) {
        console.log(error);
      }
    }
    fetchData();
    return () => {};
  }, []);
  return (
    <div className="news mt-[9pc]">
      <div className="container">
        <div className="news__content">
          <Link to={"/news"}>
            <h1 className="mb-[2.5pc]">НОВОСТИ</h1>
          </Link>
          <div className="news__content__parent flex justify-between items-center">
            {data.length > 0 ? (
              data.map((el: NewsType) => (
                <NewsChild
                  data={el.data}
                  el={el}
                  title={el.title}
                  image={el.image}
                  description={el.description}
                />
              ))
            ) : (
              <div className="w-full m-auto flex justify-center mt-[100px]">
                {/* <h1 className="text-center">No news articles found</h1> */}
                <div>
                  <div className="loader"></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default News;
