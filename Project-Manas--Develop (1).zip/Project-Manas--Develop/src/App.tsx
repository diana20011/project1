import Myrouter from "./Myrouter/Myrouter";

function App() {
  return (
    <>
      <Myrouter />
    </>
  );
}

export default App;
