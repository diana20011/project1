export interface NewsType {
  doc?: any;
  data: any;
  el?: any;
  title?: string;
  image?: string;
  description?: string;
}
export interface ImageType {
  image: string;
  el: string;
}
